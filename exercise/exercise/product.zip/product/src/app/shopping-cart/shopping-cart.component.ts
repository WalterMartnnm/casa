import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';

const CART_KEY = 'gmart_cart';

export interface CartItem {
  id: number | string;
  name: string;
  brand?: string;
  pricePhp: number;
  imageUrl?: string;
  qty: number;
}

@Component({
  selector: 'app-shopping-cart',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css'],
})
export class ShoppingCartComponent implements OnInit {
  items: CartItem[] = [];
  count = 0;
  subtotal = 0;

  constructor(private router: Router) {}

  ngOnInit(): void { this.load(); }

  private readCart(): CartItem[] {
    try {
      const raw = localStorage.getItem(CART_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw) as any[];
      return (parsed || []).map(p => ({
        id: p.id,
        name: p.name,
        brand: p.brand ?? '',
        pricePhp: Number(p.pricePhp) || 0,
        imageUrl: p.imageUrl ?? '',
        qty: Number(p.qty) > 0 ? Number(p.qty) : 1,
      }));
    } catch { return []; }
  }

  private writeCart(items: CartItem[]): void {
    localStorage.setItem(CART_KEY, JSON.stringify(items));
  }

  private recompute(): void {
    this.count = this.items.reduce((s, i) => s + i.qty, 0);
    this.subtotal = this.items.reduce((s, i) => s + i.qty * i.pricePhp, 0);
  }

  load(): void { this.items = this.readCart(); this.recompute(); }
  inc(it: CartItem): void { it.qty += 1; this.writeCart(this.items); this.recompute(); }
  dec(it: CartItem): void {
    if (it.qty > 1) { it.qty -= 1; this.writeCart(this.items); this.recompute(); }
    else { this.remove(it); }
  }
  remove(it: CartItem): void { this.items = this.items.filter(x => x.id !== it.id); this.writeCart(this.items); this.recompute(); }
  clear(): void { this.items = []; this.writeCart(this.items); this.recompute(); }

  /** programmatic navigation */
  goCheckout(): void {
    this.router.navigate(['/order']);
  }

  trackById = (_: number, it: CartItem) => it.id;
}
