import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PerfumeService } from '../../service/perfume.service';
import { CartService } from '../../service/cart.service';

export interface Perfume {
  id: number;
  perfumeName: string;
  brand: string;
  occasion?: string | null;
  pricePhp: number;
  volumeMl?: number | null;
  category?: string | null;
  imageUrl?: string | null;
}

@Component({
  selector: 'app-perfume-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './perfume-list.component.html',
  styleUrls: ['./perfume-list.component.css']
})
export class PerfumeListComponent implements OnInit {
  perfumes: Perfume[] = [];
  loading = false;

  occasions = ['Date Night', 'Club/Party', 'Office', 'Casual', 'Daily'];
  selectedOccasion = 'Date Night';

  // ✅ used by *ngFor; avoids the TS2339 error
  trackById = (index: number, p: Perfume) => p?.id ?? p?.perfumeName ?? index;

  constructor(
    private perfumesSvc: PerfumeService,
    private cart: CartService
  ) {}

  ngOnInit(): void {
    this.loadAll();
  }

  loadAll(): void {
    this.loading = true;
    this.perfumesSvc.getAll().subscribe((list: Perfume[]) => {
      this.perfumes = list;
      this.loading = false;
    });
  }

  filterByOccasion(): void {
    this.loading = true;
    this.perfumesSvc.getByOccasion(this.selectedOccasion).subscribe((list: Perfume[]) => {
      this.perfumes = list;
      this.loading = false;
    });
  }

 addToCart(p: Perfume): void {
  this.cart.addToCart(
    {
      id: p.id,
      name: p.perfumeName,
      brand: p.brand,
      pricePhp: p.pricePhp,
      // Option A: keep type as string | undefined
      imageUrl: p.imageUrl ?? undefined,
      // Option B: always send a string (if your CartItem.imageUrl is just 'string')
      // imageUrl: p.imageUrl ?? '/assets/placeholder.png',
    },
    1
  );
  alert(`Added: ${p.perfumeName}`);
}


  /** Ensure the image path is absolute and fallback if missing */
  normalizeSrc(u?: string | null): string {
    if (!u || !u.trim()) return '/assets/placeholder.png';
    return u.startsWith('/') ? u : '/' + u;
  }

  /** Fallback if an image fails to load */
  onImgErr(ev: Event): void {
    (ev.target as HTMLImageElement).src = '/assets/placeholder.png';
  }
}
