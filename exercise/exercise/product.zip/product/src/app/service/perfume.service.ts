// src/app/service/perfume.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Perfume } from '../model/perfume';

@Injectable({ providedIn: 'root' })
export class PerfumeService {
  private readonly base = '/api/perfumes';
  constructor(private http: HttpClient) {}

  getAll(): Observable<Perfume[]> {
    return this.http.get<Perfume[]>(this.base);
  }

  getByOccasion(occasion: string): Observable<Perfume[]> {
    return this.http.get<Perfume[]>(
      `${this.base}?occasion=${encodeURIComponent(occasion)}`
    );
  }
}
