import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Perfume } from '../model/perfume';

@Injectable({ providedIn: 'root' })
export class ProductService {
  constructor(private http: HttpClient) {}
  getAll(): Observable<Perfume[]> {
    // change this path if your backend list endpoint differs
    return this.http.get<Perfume[]>('/api/perfumes');
  }
}

