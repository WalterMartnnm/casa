import { Injectable } from '@angular/core';
import { BehaviorSubject, map, Observable } from 'rxjs';

export interface CartItem {
  id: number;
  name: string;
  brand: string;
  pricePhp: number;
  imageUrl?: string;
  qty: number;
}
export interface CartState { items: CartItem[]; }

const KEY = 'gmart_cart';

@Injectable({ providedIn: 'root' })
export class CartService {
  /** in-memory state + subject */
  private state: CartState = this.load();
  private stateSubject = new BehaviorSubject<CartState>(this.state);

  /** reactive streams (what the component uses) */
  readonly state$    = this.stateSubject.asObservable();
  readonly items$:    Observable<CartItem[]> = this.state$.pipe(map(s => s.items));
  readonly count$:    Observable<number>     = this.state$.pipe(map(s => s.items.reduce((a,i)=>a + i.qty, 0)));
  readonly subtotal$: Observable<number>     = this.state$.pipe(map(s => s.items.reduce((a,i)=>a + i.qty * i.pricePhp, 0)));

  /** keep your existing sync helpers too (optional) */
  items(): CartItem[] { return this.state.items; }
  count(): number { return this.state.items.reduce((a,i)=>a + i.qty, 0); }
  subtotal(): number { return this.state.items.reduce((a,i)=>a + i.qty * i.pricePhp, 0); }

  /** mutations */
  addToCart(item: Omit<CartItem,'qty'>, qty: number = 1): void {
    const ex = this.state.items.find(x => x.id === item.id);
    if (ex) ex.qty += qty;
    else this.state.items.push({ ...item, qty: Math.max(1, qty) });
    this.commit();
  }
  setQty(id: number, qty: number): void {
    const it = this.state.items.find(x => x.id === id);
    if (!it) return;
    it.qty = Math.max(1, qty);
    this.commit();
  }
  remove(id: number): void {
    this.state.items = this.state.items.filter(x => x.id !== id);
    this.commit();
  }
  clear(): void {
    this.state.items = [];
    this.commit();
  }

  /** persistence + state fanout */
  private load(): CartState {
    try { return JSON.parse(localStorage.getItem(KEY) || '{"items":[]}'); }
    catch { return { items: [] }; }
  }
  private save(): void { localStorage.setItem(KEY, JSON.stringify(this.state)); }
  private commit(): void {
    this.save();
    this.stateSubject.next(this.state); // <- notifies items$/count$/subtotal$
  }
}
