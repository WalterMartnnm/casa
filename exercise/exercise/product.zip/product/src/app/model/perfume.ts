// src/app/model/perfume.ts
export interface Perfume {
  id: number;
  perfumeName: string;
  brand: string;
  occasion: string;
  pricePhp: number;
  volumeMl: number;
  concentration: string;
  imageUrl: string;
  category: string;
}
