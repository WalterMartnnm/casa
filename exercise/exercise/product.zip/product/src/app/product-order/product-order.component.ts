import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { CartService, CartItem } from '../service/cart.service';

@Component({
  selector: 'app-product-order',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './product-order.component.html',
  styleUrls: ['./product-order.component.css']
})
export class ProductOrderComponent implements OnInit {

  // ----- cart summary -----
  items: CartItem[] = [];
  subtotal = 0;
  shipping = 0;
  total = 0;

  // ----- simple checkout form model -----
  form = {
    fullName: '',
    phone: '',
    address: '',
    paymentMethod: 'COD',   // COD | GCash | Card
    notes: ''
  };

  // ----- constants / storage -----
  private readonly FREE_SHIPPING_MIN = 5000;
  private readonly SHIPPING_FEE = 150;
  private readonly ORDERS_KEY = 'orders_v1';

  constructor(private cart: CartService, private router: Router) {}

  // Load cart + compute totals
  ngOnInit(): void {
    this.refreshFromCart();
  }

  // Called by plus/minus in the summary (optional)
  inc(i: CartItem) { this.cart.setQty(i.id, i.qty + 1); this.refreshFromCart(); }
  dec(i: CartItem) { this.cart.setQty(i.id, Math.max(1, i.qty - 1)); this.refreshFromCart(); }
  remove(i: CartItem) { this.cart.remove(i.id); this.refreshFromCart(); }
  clearCart() { this.cart.clear(); this.refreshFromCart(); }

  // Main action: validate → persist → clear → go success
  placeOrder(): void {
    if (!this.items.length) { alert('Your cart is empty.'); return; }
    const error = this.validateForm();
    if (error) { alert(error); return; }

    const order = {
      id: this.genId(),
      createdAt: new Date().toISOString(),
      items: this.clone(this.items),
      subtotal: this.subtotal,
      shipping: this.shipping,
      total: this.total,
      customer: this.clone(this.form)
    };

    const all = this.loadOrders();
    all.push(order);
    localStorage.setItem(this.ORDERS_KEY, JSON.stringify(all));

    this.cart.clear();
    this.refreshFromCart();

    this.router.navigate(['/order-success', order.id]);
  }

  // ---------- helpers ----------

  private refreshFromCart(): void {
    this.items = this.cart.items();          // snapshot from service
    this.subtotal = this.cart.subtotal();
    this.shipping = this.subtotal >= this.FREE_SHIPPING_MIN ? 0 : (this.items.length ? this.SHIPPING_FEE : 0);
    this.total = this.subtotal + this.shipping;
  }

  private validateForm(): string | null {
    if (!this.form.fullName.trim()) return 'Please enter your full name.';
    if (!this.form.phone.trim()) return 'Please enter your phone number.';
    if (!this.form.address.trim()) return 'Please enter your address.';
    return null;
  }

  private loadOrders(): any[] {
    try { return JSON.parse(localStorage.getItem(this.ORDERS_KEY) || '[]'); }
    catch { return []; }
  }

  private genId(): string {
    return 'ORD-' + Math.random().toString(36).slice(2,7).toUpperCase()
           + '-' + Date.now().toString().slice(-5);
  }

  private clone<T>(v: T): T {
    return JSON.parse(JSON.stringify(v));
  }
}
